# MedLink — Universal Health ID

A full-featured medical identity platform built with Next.js 14 (App Router). Includes patient dashboards, AI health assistant, emergency mode, doctor and hospital dashboards, and an admin panel.

## Features

- **Patient Dashboard** — medication tracker, appointments, records, vaccinations
- **Medical Card** — printable digital health ID card
- **Health Profile** — editable patient information with BMI, allergies, conditions
- **AI Health Assistant** — chat powered by Claude AI (patient-context aware)
- **Emergency Mode** — SOS button with live medical summary for first responders
- **Doctor Dashboard** — patient queue with AI clinical support notes
- **Hospital Dashboard** — ward management and admitted patient tracker
- **Admin Dashboard** — user management and audit logs
- **Persistent storage** — data saved to localStorage across sessions

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

Copy `.env.local` and add your Anthropic API key:

```bash
cp .env.local .env.local
```

Edit `.env.local`:

```
ANTHROPIC_API_KEY=sk-ant-...your-key-here...
```

Get a key at [console.anthropic.com](https://console.anthropic.com).

### 3. Run the dev server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

### 4. Sign in

Click **Sign In** on the auth screen (demo credentials are pre-filled). No backend auth — this is a demo app.

## Project Structure

```
medlink/
├── app/
│   ├── layout.jsx          # Root layout + metadata
│   ├── page.jsx            # Main app shell (sidebar + routing)
│   ├── globals.css         # Global resets and keyframes
│   └── api/
│       └── claude/
│           └── route.js    # Anthropic API proxy (keeps key server-side)
├── components/
│   ├── UI.jsx              # Shared primitives: Avatar, Badge, Card, Btn, Input
│   ├── MedicalCard.jsx     # Printable health ID card
│   ├── PatientDashboard.jsx
│   ├── HealthProfile.jsx
│   ├── AIAssistant.jsx
│   ├── EmergencyMode.jsx
│   ├── DoctorDashboard.jsx
│   ├── HospitalDashboard.jsx
│   ├── AdminDashboard.jsx
│   └── AuthScreen.jsx
├── lib/
│   ├── constants.js        # Colour tokens + all initial demo data
│   └── storage.js          # localStorage helpers (replaces artifact window.storage)
├── .env.local              # API key (never commit this)
├── next.config.js
└── package.json
```

## Deploying to Vercel

```bash
npm i -g vercel
vercel
```

Add `ANTHROPIC_API_KEY` as an environment variable in the Vercel project settings.

## Notes

- The AI features call `/api/claude` which proxies to Anthropic — your key is never exposed to the browser.
- Patient data is persisted in `localStorage`; no database is required for the demo.
- To add real auth, replace `AuthScreen` with NextAuth or Clerk.

"use client";
import { useState } from "react";
import { C, HOSPITAL_PATIENTS } from "../lib/constants";
import { Card, StatCard, SectionTitle, Badge } from "./UI";

export default function HospitalDashboard() {
  const [search, setSearch] = useState("");
  const filtered = HOSPITAL_PATIENTS.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.id.includes(search) ||
      p.ward.toLowerCase().includes(search.toLowerCase())
  );

  const wardCounts = HOSPITAL_PATIENTS.reduce((acc, p) => {
    acc[p.ward] = (acc[p.ward] || 0) + 1;
    return acc;
  }, {});

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <SectionTitle>Hospital Dashboard</SectionTitle>
        <Badge color={C.blue} bg={C.blueLight}>
          🏥 Apollo Hospitals · Chennai
        </Badge>
      </div>

      <div style={{ display: "flex", gap: 14 }}>
        {[
          ["Total Admitted", HOSPITAL_PATIENTS.length, C.blue],
          [
            "Critical",
            HOSPITAL_PATIENTS.filter((p) => p.status === "Critical").length,
            C.red,
          ],
          ["Departments", Object.keys(wardCounts).length, C.emerald],
          ["Doctors On Duty", "18", C.blueM],
        ].map(([l, v, c]) => (
          <StatCard key={l} label={l} value={v} color={c} />
        ))}
      </div>

      <div
        style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 20 }}
      >
        {/* Department overview */}
        <Card>
          <SectionTitle>Departments</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {Object.entries(wardCounts).map(([ward, count]) => (
              <div
                key={ward}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "10px 14px",
                  borderRadius: 10,
                  background: C.gray50,
                  border: `1px solid ${C.gray200}`,
                }}
              >
                <div style={{ fontWeight: 600, fontSize: 14, color: C.gray800 }}>
                  {ward}
                </div>
                <Badge color={C.blue} bg={C.blueLight}>
                  {count} patients
                </Badge>
              </div>
            ))}
            {["Orthopedics", "Neurology", "Pediatrics"].map((w) => (
              <div
                key={w}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "10px 14px",
                  borderRadius: 10,
                  background: C.gray50,
                  border: `1px solid ${C.gray200}`,
                }}
              >
                <div style={{ fontWeight: 600, fontSize: 14, color: C.gray400 }}>
                  {w}
                </div>
                <Badge color={C.gray400} bg={C.gray100}>
                  0 patients
                </Badge>
              </div>
            ))}
          </div>
        </Card>

        {/* Patient list */}
        <Card>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 14,
            }}
          >
            <SectionTitle>Admitted Patients</SectionTitle>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, ID, ward..."
              style={{
                padding: "7px 12px",
                borderRadius: 20,
                border: `1px solid ${C.gray200}`,
                fontSize: 13,
                width: 200,
              }}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "0.8fr 1.5fr 1fr 0.7fr 1fr 0.8fr",
                gap: 8,
                padding: "6px 10px",
                borderBottom: `1px solid ${C.gray200}`,
              }}
            >
              {["ID", "Name", "Ward", "Bed", "Admitted", "Status"].map((h) => (
                <div
                  key={h}
                  style={{
                    fontSize: 11,
                    fontWeight: 700,
                    color: C.gray400,
                    letterSpacing: "0.05em",
                  }}
                >
                  {h}
                </div>
              ))}
            </div>
            {filtered.map((p) => (
              <div
                key={p.id}
                style={{
                  display: "grid",
                  gridTemplateColumns: "0.8fr 1.5fr 1fr 0.7fr 1fr 0.8fr",
                  gap: 8,
                  padding: "10px",
                  borderRadius: 10,
                  background:
                    p.status === "Critical" ? C.redLight : C.gray50,
                  border: `1px solid ${
                    p.status === "Critical" ? "#F5C1BE" : C.gray200
                  }`,
                  alignItems: "center",
                }}
              >
                <div style={{ fontSize: 11, fontWeight: 700, color: C.gray400 }}>
                  {p.id}
                </div>
                <div style={{ fontWeight: 600, fontSize: 13, color: C.gray800 }}>
                  {p.name}
                </div>
                <div style={{ fontSize: 13, color: C.gray600 }}>{p.ward}</div>
                <div style={{ fontSize: 13, color: C.gray600 }}>{p.bed}</div>
                <div style={{ fontSize: 12, color: C.gray400 }}>
                  {p.admitted}
                </div>
                <Badge
                  color={
                    p.status === "Critical"
                      ? C.red
                      : p.status === "Stable"
                      ? C.emerald
                      : C.blue
                  }
                  bg={
                    p.status === "Critical"
                      ? C.redLight
                      : p.status === "Stable"
                      ? C.emeraldLight
                      : C.blueLight
                  }
                >
                  {p.status}
                </Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

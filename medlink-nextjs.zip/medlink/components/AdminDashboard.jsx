"use client";
import { C } from "../lib/constants";
import { Card, StatCard, SectionTitle, Badge } from "./UI";

const USERS = [
  { name: "Arjun Sharma", role: "Patient", joined: "2025-01-10", status: "Active", id: "MED-7741" },
  { name: "Dr. Ravi Kumar", role: "Doctor", joined: "2024-12-01", status: "Verified", id: "DOC-0021" },
  { name: "Apollo Hospitals", role: "Hospital", joined: "2024-11-15", status: "Active", id: "HOS-0005" },
  { name: "Meera Nair", role: "Patient", joined: "2025-03-08", status: "Active", id: "MED-7890" },
  { name: "Dr. Anita Menon", role: "Doctor", joined: "2025-02-14", status: "Pending", id: "DOC-0034" },
];

const LOGS = [
  { time: "06:14:21", event: "QR Scan", user: "MED-7741", detail: "Emergency scan · ICU-3", level: "info" },
  { time: "06:10:05", event: "Login", user: "DOC-0021", detail: "Doctor portal login · Chennai", level: "ok" },
  { time: "05:58:44", event: "Record Upload", user: "MED-7890", detail: "Blood report uploaded", level: "ok" },
  { time: "05:44:12", event: "Failed Login", user: "Unknown", detail: "3 failed attempts · IP blocked", level: "danger" },
  { time: "05:30:00", event: "New Signup", user: "HOS-0008", detail: "New hospital registered", level: "info" },
];

export default function AdminDashboard() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <SectionTitle>Admin Dashboard</SectionTitle>

      <div style={{ display: "flex", gap: 14 }}>
        {[
          ["Total Users", "12,847", C.blue],
          ["Doctors Verified", "340", C.emerald],
          ["Hospitals", "28", C.blueM],
          ["QR Scans Today", "1,204", C.amber],
        ].map(([l, v, c]) => (
          <StatCard key={l} label={l} value={v} color={c} />
        ))}
      </div>

      <div
        style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 20 }}
      >
        {/* User management */}
        <Card>
          <SectionTitle>User Management</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1.5fr 1fr 1fr 1fr 0.7fr",
                gap: 8,
                padding: "4px 10px",
                borderBottom: `1px solid ${C.gray200}`,
              }}
            >
              {["Name", "Role", "ID", "Joined", "Status"].map((h) => (
                <div
                  key={h}
                  style={{
                    fontSize: 11,
                    fontWeight: 700,
                    color: C.gray400,
                    letterSpacing: "0.05em",
                  }}
                >
                  {h}
                </div>
              ))}
            </div>
            {USERS.map((u) => (
              <div
                key={u.id}
                style={{
                  display: "grid",
                  gridTemplateColumns: "1.5fr 1fr 1fr 1fr 0.7fr",
                  gap: 8,
                  padding: "9px 10px",
                  borderRadius: 8,
                  background: C.gray50,
                  border: `1px solid ${C.gray200}`,
                  alignItems: "center",
                }}
              >
                <div
                  style={{ fontWeight: 600, fontSize: 13, color: C.gray800 }}
                >
                  {u.name}
                </div>
                <Badge
                  color={
                    u.role === "Doctor"
                      ? C.blue
                      : u.role === "Hospital"
                      ? C.emerald
                      : C.gray600
                  }
                  bg={
                    u.role === "Doctor"
                      ? C.blueLight
                      : u.role === "Hospital"
                      ? C.emeraldLight
                      : C.gray100
                  }
                >
                  {u.role}
                </Badge>
                <div style={{ fontSize: 11, color: C.gray400 }}>{u.id}</div>
                <div style={{ fontSize: 12, color: C.gray400 }}>{u.joined}</div>
                <Badge
                  color={
                    u.status === "Verified"
                      ? C.emerald
                      : u.status === "Active"
                      ? C.blue
                      : C.amber
                  }
                  bg={
                    u.status === "Verified"
                      ? C.emeraldLight
                      : u.status === "Active"
                      ? C.blueLight
                      : C.amberLight
                  }
                >
                  {u.status}
                </Badge>
              </div>
            ))}
          </div>
        </Card>

        {/* Audit logs */}
        <Card>
          <SectionTitle>Audit Logs</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {LOGS.map((l, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  gap: 10,
                  alignItems: "flex-start",
                  padding: "8px 10px",
                  borderRadius: 8,
                  background: l.level === "danger" ? C.redLight : C.gray50,
                  border: `1px solid ${
                    l.level === "danger" ? "#F5C1BE" : C.gray200
                  }`,
                }}
              >
                <div
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: "50%",
                    background:
                      l.level === "danger"
                        ? C.red
                        : l.level === "ok"
                        ? C.emerald
                        : C.blue,
                    marginTop: 4,
                    flexShrink: 0,
                  }}
                />
                <div style={{ flex: 1 }}>
                  <div
                    style={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <span
                      style={{
                        fontSize: 13,
                        fontWeight: 700,
                        color: C.gray800,
                      }}
                    >
                      {l.event}
                    </span>
                    <span style={{ fontSize: 11, color: C.gray400 }}>
                      {l.time}
                    </span>
                  </div>
                  <div style={{ fontSize: 11, color: C.gray400 }}>
                    {l.user} · {l.detail}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

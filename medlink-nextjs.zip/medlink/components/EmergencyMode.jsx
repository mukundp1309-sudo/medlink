"use client";
import { useState, useEffect } from "react";
import { C } from "../lib/constants";
import { Card, SectionTitle, Badge } from "./UI";

export default function EmergencyMode({ patient }) {
  const [active, setActive] = useState(false);
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    if (!active) {
      setCountdown(5);
      return;
    }
    if (countdown === 0) return;
    const t = setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [active, countdown]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <SectionTitle>Emergency Mode</SectionTitle>

      {/* SOS Button */}
      <Card
        style={{
          textAlign: "center",
          padding: 40,
          background: active ? "#FFF0EE" : C.white,
        }}
      >
        <div style={{ fontSize: 14, color: C.gray400, marginBottom: 20 }}>
          Tap to send emergency SOS alert with your location and medical summary
        </div>
        <div
          onClick={() => setActive(!active)}
          style={{
            width: 140,
            height: 140,
            borderRadius: "50%",
            background: active ? C.red : C.redLight,
            border: `4px solid ${C.red}`,
            cursor: "pointer",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            margin: "0 auto 20px",
            boxShadow: active ? `0 0 0 20px rgba(192,57,43,0.15)` : "none",
            transition: "all 0.3s",
          }}
        >
          <div style={{ fontSize: 40 }}>🆘</div>
          <div
            style={{
              fontSize: 14,
              fontWeight: 700,
              color: active ? C.white : C.red,
              marginTop: 4,
            }}
          >
            {active
              ? countdown > 0
                ? `Cancel (${countdown})`
                : "ACTIVE"
              : "SOS"}
          </div>
        </div>
        {active && countdown === 0 && (
          <Badge color={C.red} bg={C.redLight}>
            📡 Live · Emergency contacts notified · Location shared
          </Badge>
        )}
      </Card>

      {/* Emergency info card */}
      <Card style={{ border: `2px solid ${C.red}` }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            marginBottom: 16,
          }}
        >
          <div style={{ fontSize: 20 }}>🚨</div>
          <div style={{ fontWeight: 700, fontSize: 15, color: C.red }}>
            Emergency Medical Information
          </div>
          <div style={{ fontSize: 11, color: C.gray400, marginLeft: "auto" }}>
            Visible to all responders · No login required
          </div>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr 1fr",
            gap: 14,
          }}
        >
          <div
            style={{ background: C.redLight, borderRadius: 12, padding: 14 }}
          >
            <div
              style={{
                fontSize: 11,
                fontWeight: 700,
                color: C.red,
                letterSpacing: "0.06em",
              }}
            >
              BLOOD GROUP
            </div>
            <div
              style={{
                fontSize: 32,
                fontWeight: 800,
                color: C.red,
                marginTop: 4,
              }}
            >
              {patient.blood}
            </div>
          </div>
          <div
            style={{ background: C.amberLight, borderRadius: 12, padding: 14 }}
          >
            <div
              style={{
                fontSize: 11,
                fontWeight: 700,
                color: C.amber,
                letterSpacing: "0.06em",
              }}
            >
              ALLERGIES
            </div>
            <div
              style={{
                fontSize: 13,
                fontWeight: 700,
                color: C.amber,
                marginTop: 6,
                lineHeight: 1.5,
              }}
            >
              {patient.allergies.join(", ")}
            </div>
          </div>
          <div
            style={{ background: C.blueLight, borderRadius: 12, padding: 14 }}
          >
            <div
              style={{
                fontSize: 11,
                fontWeight: 700,
                color: C.blue,
                letterSpacing: "0.06em",
              }}
            >
              CONDITIONS
            </div>
            <div
              style={{
                fontSize: 12,
                fontWeight: 600,
                color: C.blue,
                marginTop: 6,
                lineHeight: 1.6,
              }}
            >
              {patient.conditions.join(", ")}
            </div>
          </div>
        </div>

        <div
          style={{
            marginTop: 14,
            padding: 14,
            background: C.gray50,
            borderRadius: 12,
            border: `1px solid ${C.gray200}`,
          }}
        >
          <div
            style={{
              fontSize: 11,
              fontWeight: 700,
              color: C.gray400,
              letterSpacing: "0.06em",
              marginBottom: 8,
            }}
          >
            EMERGENCY CONTACTS
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ fontSize: 20 }}>📞</div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14, color: C.gray800 }}>
                {patient.emergencyContact.name}
              </div>
              <div style={{ fontSize: 12, color: C.gray400 }}>
                {patient.emergencyContact.relation} ·{" "}
                {patient.emergencyContact.phone}
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

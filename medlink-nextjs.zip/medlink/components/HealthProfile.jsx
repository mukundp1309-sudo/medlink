"use client";
import { useState } from "react";
import { C } from "../lib/constants";
import { Card, SectionTitle, Btn, Input, Badge } from "./UI";
import { tagStyle } from "./UI";

export default function HealthProfile({ patient, setPatient }) {
  const [edit, setEdit] = useState(false);
  const [form, setForm] = useState(patient);
  const [newAllergy, setNewAllergy] = useState("");

  const bmi = (patient.weight / (patient.height / 100) ** 2).toFixed(1);
  const bmiColor =
    bmi < 18.5
      ? C.amber
      : bmi < 25
      ? C.emerald
      : bmi < 30
      ? C.amber
      : C.red;
  const bmiLabel =
    bmi < 18.5
      ? "Underweight"
      : bmi < 25
      ? "Normal"
      : bmi < 30
      ? "Overweight"
      : "Obese";

  const save = () => {
    setPatient(form);
    setEdit(false);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <SectionTitle>Health Profile</SectionTitle>
        <Btn
          variant={edit ? "secondary" : "primary"}
          onClick={() => (edit ? save() : setEdit(true))}
          small
        >
          {edit ? "Save Changes" : "Edit Profile"}
        </Btn>
      </div>

      <div
        style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}
      >
        {/* Personal info */}
        <Card>
          <div
            style={{
              fontWeight: 700,
              fontSize: 14,
              color: C.gray600,
              marginBottom: 14,
              textTransform: "uppercase",
              letterSpacing: "0.05em",
            }}
          >
            Personal
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {edit ? (
              <>
                <Input
                  label="Full Name"
                  value={form.name}
                  onChange={(v) => setForm((f) => ({ ...f, name: v }))}
                />
                <Input
                  label="Date of Birth"
                  value={form.dob}
                  onChange={(v) => setForm((f) => ({ ...f, dob: v }))}
                  type="date"
                />
                <Input
                  label="Phone"
                  value={form.phone}
                  onChange={(v) => setForm((f) => ({ ...f, phone: v }))}
                />
                <Input
                  label="Email"
                  value={form.email}
                  onChange={(v) => setForm((f) => ({ ...f, email: v }))}
                />
                <Input
                  label="Address"
                  value={form.address}
                  onChange={(v) => setForm((f) => ({ ...f, address: v }))}
                />
              </>
            ) : (
              [
                ["Full Name", patient.name],
                ["Date of Birth", patient.dob],
                ["Gender", patient.gender],
                ["Phone", patient.phone],
                ["Email", patient.email],
                ["Address", patient.address],
              ].map(([l, v]) => (
                <div
                  key={l}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    borderBottom: `1px solid ${C.gray100}`,
                    paddingBottom: 8,
                  }}
                >
                  <span style={{ fontSize: 13, color: C.gray400 }}>{l}</span>
                  <span
                    style={{
                      fontSize: 13,
                      fontWeight: 600,
                      color: C.gray800,
                      maxWidth: "55%",
                      textAlign: "right",
                    }}
                  >
                    {v}
                  </span>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Vitals + allergies + conditions */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Card>
            <div
              style={{
                fontWeight: 700,
                fontSize: 14,
                color: C.gray600,
                marginBottom: 14,
                textTransform: "uppercase",
                letterSpacing: "0.05em",
              }}
            >
              Vitals
            </div>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: 12,
              }}
            >
              {[
                ["Blood Group", patient.blood, C.red],
                ["Height", `${patient.height} cm`, C.blue],
                ["Weight", `${patient.weight} kg`, C.blue],
              ].map(([l, v, c]) => (
                <div
                  key={l}
                  style={{
                    background: C.gray50,
                    borderRadius: 10,
                    padding: 12,
                    border: `1px solid ${C.gray200}`,
                  }}
                >
                  <div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>
                    {l}
                  </div>
                  <div
                    style={{
                      fontSize: 20,
                      fontWeight: 700,
                      color: c,
                      marginTop: 4,
                    }}
                  >
                    {v}
                  </div>
                </div>
              ))}
              <div
                style={{
                  background: C.gray50,
                  borderRadius: 10,
                  padding: 12,
                  border: `1px solid ${C.gray200}`,
                }}
              >
                <div style={{ fontSize: 11, color: C.gray400, fontWeight: 600 }}>
                  BMI
                </div>
                <div
                  style={{
                    fontSize: 20,
                    fontWeight: 700,
                    color: bmiColor,
                    marginTop: 4,
                  }}
                >
                  {bmi}
                </div>
                <div style={{ fontSize: 10, color: bmiColor }}>{bmiLabel}</div>
              </div>
            </div>
          </Card>

          <Card>
            <div
              style={{
                fontWeight: 700,
                fontSize: 14,
                color: C.gray600,
                marginBottom: 12,
                textTransform: "uppercase",
                letterSpacing: "0.05em",
              }}
            >
              Allergies
            </div>
            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                gap: 6,
                marginBottom: edit ? 10 : 0,
              }}
            >
              {patient.allergies.map((a) => (
                <div
                  key={a}
                  style={{ ...tagStyle(C.red, C.redLight), gap: 5, cursor: edit ? "pointer" : "default" }}
                  onClick={() =>
                    edit &&
                    setPatient((p) => ({
                      ...p,
                      allergies: p.allergies.filter((x) => x !== a),
                    }))
                  }
                >
                  {a}
                  {edit && " ×"}
                </div>
              ))}
            </div>
            {edit && (
              <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                <input
                  value={newAllergy}
                  onChange={(e) => setNewAllergy(e.target.value)}
                  placeholder="Add allergy..."
                  style={{
                    flex: 1,
                    padding: "7px 10px",
                    borderRadius: 8,
                    border: `1px solid ${C.gray200}`,
                    fontSize: 13,
                  }}
                />
                <Btn
                  small
                  onClick={() => {
                    if (newAllergy) {
                      setPatient((p) => ({
                        ...p,
                        allergies: [...p.allergies, newAllergy],
                      }));
                      setNewAllergy("");
                    }
                  }}
                >
                  Add
                </Btn>
              </div>
            )}
          </Card>

          <Card>
            <div
              style={{
                fontWeight: 700,
                fontSize: 14,
                color: C.gray600,
                marginBottom: 12,
                textTransform: "uppercase",
                letterSpacing: "0.05em",
              }}
            >
              Conditions
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {patient.conditions.map((c) => (
                <div
                  key={c}
                  style={{ display: "flex", alignItems: "center", gap: 8 }}
                >
                  <div
                    style={{
                      width: 7,
                      height: 7,
                      borderRadius: "50%",
                      background: C.amber,
                      flexShrink: 0,
                    }}
                  />
                  <span style={{ fontSize: 13, color: C.gray800 }}>{c}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

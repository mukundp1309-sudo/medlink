"use client";
import { useState } from "react";
import { C, DOCTOR_QUEUE } from "../lib/constants";
import { Card, StatCard, SectionTitle, Avatar, Badge, Btn } from "./UI";

export default function DoctorDashboard() {
  const [selected, setSelected] = useState(null);
  const [note, setNote] = useState("");
  const [rx, setRx] = useState("");
  const [aiNote, setAiNote] = useState("");
  const [loadingAI, setLoadingAI] = useState(false);

  const getAISupport = async (patient) => {
    setLoadingAI(true);
    setAiNote("");
    try {
      const res = await fetch("/api/claude", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          max_tokens: 500,
          messages: [
            {
              role: "user",
              content: `You are MedLink AI assisting a cardiologist. Patient: ${patient.name}, ${patient.age}${patient.gender}, Blood: ${patient.blood}, Condition: ${patient.condition}, Allergy: ${patient.allergy}. Provide a brief clinical summary with 2-3 key considerations and any allergy warnings. Be concise and clinically relevant.`,
            },
          ],
        }),
      });
      const data = await res.json();
      setAiNote(data.content?.[0]?.text || "Unable to generate AI support.");
    } catch {
      setAiNote("AI support unavailable.");
    }
    setLoadingAI(false);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <SectionTitle>Doctor Dashboard</SectionTitle>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Avatar initials="DR" size={36} bg={C.navy} />
          <div>
            <div style={{ fontWeight: 700, fontSize: 14, color: C.gray800 }}>
              Dr. Ravi Kumar
            </div>
            <div style={{ fontSize: 12, color: C.gray400 }}>
              Cardiologist · Apollo Hospitals
            </div>
          </div>
          <Badge color={C.emerald} bg={C.emeraldLight}>
            ● Verified
          </Badge>
        </div>
      </div>

      <div style={{ display: "flex", gap: 14 }}>
        {[
          ["Today's Patients", "12", C.blue],
          ["Pending Reviews", "4", C.amber],
          ["Prescriptions", "38", C.emerald],
          ["Upcoming", "3", C.blueM],
        ].map(([l, v, c]) => (
          <StatCard key={l} label={l} value={v} color={c} />
        ))}
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1.4fr",
          gap: 20,
        }}
      >
        {/* Queue */}
        <Card>
          <SectionTitle>Patient Queue</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {DOCTOR_QUEUE.map((p) => (
              <div
                key={p.name}
                onClick={() => {
                  setSelected(p);
                  setNote("");
                  setRx("");
                  setAiNote("");
                }}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "10px 12px",
                  borderRadius: 12,
                  border: `1.5px solid ${
                    selected?.name === p.name ? C.blue : C.gray200
                  }`,
                  background:
                    selected?.name === p.name
                      ? C.blueLight
                      : p.status === "In"
                      ? "#EEF9F5"
                      : C.gray50,
                  cursor: "pointer",
                }}
              >
                <Avatar
                  initials={p.initials}
                  size={36}
                  bg={p.status === "In" ? C.emerald : C.gray200}
                  color={p.status === "In" ? C.white : C.gray600}
                />
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      fontWeight: 700,
                      fontSize: 13,
                      color: C.gray800,
                    }}
                  >
                    {p.name}
                  </div>
                  <div style={{ fontSize: 11, color: C.gray400 }}>
                    {p.blood} · {p.age}
                    {p.gender} · {p.condition}
                  </div>
                </div>
                <Badge
                  color={
                    p.status === "In"
                      ? C.emerald
                      : p.status === "Next"
                      ? C.amber
                      : C.gray600
                  }
                  bg={
                    p.status === "In"
                      ? C.emeraldLight
                      : p.status === "Next"
                      ? C.amberLight
                      : C.gray100
                  }
                >
                  {p.status}
                </Badge>
              </div>
            ))}
          </div>
        </Card>

        {/* Patient detail */}
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {selected ? (
            <Card>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  marginBottom: 14,
                }}
              >
                <div>
                  <div
                    style={{
                      fontSize: 18,
                      fontWeight: 700,
                      color: C.gray800,
                    }}
                  >
                    {selected.name}
                  </div>
                  <div style={{ fontSize: 13, color: C.gray400 }}>
                    {selected.blood} · {selected.age}
                    {selected.gender} · {selected.condition}
                  </div>
                  {selected.allergy !== "None" && (
                    <Badge
                      color={C.red}
                      bg={C.redLight}
                      style={{ marginTop: 6 }}
                    >
                      ⚠ Allergy: {selected.allergy}
                    </Badge>
                  )}
                </div>
                <Btn
                  variant="secondary"
                  small
                  onClick={() => getAISupport(selected)}
                >
                  🤖 AI Support
                </Btn>
              </div>

              {(aiNote || loadingAI) && (
                <div
                  style={{
                    background: C.blueLight,
                    border: `1px solid #C4DEFA`,
                    borderRadius: 10,
                    padding: 12,
                    marginBottom: 12,
                    fontSize: 13,
                    color: C.gray800,
                    lineHeight: 1.6,
                  }}
                >
                  <div
                    style={{
                      fontWeight: 700,
                      color: C.blue,
                      fontSize: 11,
                      marginBottom: 6,
                    }}
                  >
                    🤖 AI CLINICAL SUPPORT
                  </div>
                  {loadingAI ? "Analyzing patient data..." : aiNote}
                </div>
              )}

              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                <div>
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      color: C.gray400,
                      marginBottom: 6,
                    }}
                  >
                    DIAGNOSIS / NOTE
                  </div>
                  <textarea
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    rows={3}
                    placeholder="Add clinical notes, observations..."
                    style={{
                      width: "100%",
                      padding: 10,
                      borderRadius: 8,
                      border: `1px solid ${C.gray200}`,
                      fontSize: 13,
                      resize: "vertical",
                      fontFamily: "inherit",
                    }}
                  />
                </div>
                <div>
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      color: C.gray400,
                      marginBottom: 6,
                    }}
                  >
                    PRESCRIPTION
                  </div>
                  <textarea
                    value={rx}
                    onChange={(e) => setRx(e.target.value)}
                    rows={3}
                    placeholder="Drug name, dosage, instructions..."
                    style={{
                      width: "100%",
                      padding: 10,
                      borderRadius: 8,
                      border: `1px solid ${C.gray200}`,
                      fontSize: 13,
                      resize: "vertical",
                      fontFamily: "inherit",
                    }}
                  />
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <Btn variant="primary" small>
                    💊 Issue Prescription
                  </Btn>
                  <Btn variant="secondary" small>
                    📅 Schedule Follow-up
                  </Btn>
                  <Btn variant="secondary" small>
                    📋 Save Notes
                  </Btn>
                </div>
              </div>
            </Card>
          ) : (
            <Card style={{ textAlign: "center", padding: 60, color: C.gray400 }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>👆</div>
              <div style={{ fontSize: 15 }}>
                Select a patient from the queue to view details and use AI
                support
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

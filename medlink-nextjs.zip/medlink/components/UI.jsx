"use client";
import { C } from "../lib/constants";

// ─── TAG STYLE HELPER ──────────────────────────────────────────────────────────
export const tagStyle = (color, bg) => ({
  display: "inline-flex",
  alignItems: "center",
  padding: "2px 10px",
  borderRadius: 20,
  fontSize: 11,
  fontWeight: 600,
  letterSpacing: "0.03em",
  color,
  background: bg,
});

// ─── AVATAR ────────────────────────────────────────────────────────────────────
export function Avatar({ initials, size = 40, bg = C.blue, color = "#fff" }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        background: bg,
        color,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontWeight: 700,
        fontSize: size * 0.35,
        flexShrink: 0,
      }}
    >
      {initials}
    </div>
  );
}

// ─── BADGE ─────────────────────────────────────────────────────────────────────
export function Badge({ children, color = C.blue, bg = C.blueLight }) {
  return <span style={tagStyle(color, bg)}>{children}</span>;
}

// ─── CARD ──────────────────────────────────────────────────────────────────────
export function Card({ children, style = {}, p = 20 }) {
  return (
    <div
      style={{
        background: C.white,
        borderRadius: 16,
        padding: p,
        boxShadow: "0 1px 4px rgba(0,0,0,0.07)",
        border: `1px solid ${C.gray200}`,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// ─── STAT CARD ─────────────────────────────────────────────────────────────────
export function StatCard({ label, value, color = C.blue }) {
  return (
    <Card p={16} style={{ flex: 1 }}>
      <div
        style={{
          fontSize: 11,
          color: C.gray400,
          fontWeight: 600,
          letterSpacing: "0.06em",
          marginBottom: 6,
        }}
      >
        {label.toUpperCase()}
      </div>
      <div style={{ fontSize: 28, fontWeight: 700, color }}>{value}</div>
    </Card>
  );
}

// ─── SECTION TITLE ─────────────────────────────────────────────────────────────
export function SectionTitle({ children }) {
  return (
    <div
      style={{ fontSize: 16, fontWeight: 700, color: C.gray800, marginBottom: 14 }}
    >
      {children}
    </div>
  );
}

// ─── BUTTON ────────────────────────────────────────────────────────────────────
export function Btn({
  children,
  onClick,
  variant = "primary",
  style = {},
  small = false,
  disabled = false,
}) {
  const base = {
    padding: small ? "6px 14px" : "10px 20px",
    borderRadius: 10,
    fontSize: small ? 12 : 14,
    fontWeight: 600,
    cursor: disabled ? "not-allowed" : "pointer",
    border: "none",
    transition: "all 0.15s",
    opacity: disabled ? 0.55 : 1,
  };
  const variants = {
    primary: { background: C.blue, color: C.white },
    secondary: {
      background: C.gray100,
      color: C.gray800,
      border: `1px solid ${C.gray200}`,
    },
    danger: { background: C.redLight, color: C.red },
    emerald: { background: C.emerald, color: C.white },
    ghost: {
      background: "transparent",
      color: C.blue,
      textDecoration: "underline",
    },
  };
  return (
    <button
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      style={{ ...base, ...variants[variant], ...style }}
    >
      {children}
    </button>
  );
}

// ─── INPUT ─────────────────────────────────────────────────────────────────────
export function Input({
  label,
  value,
  onChange,
  type = "text",
  placeholder = "",
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      {label && (
        <label style={{ fontSize: 12, fontWeight: 600, color: C.gray600 }}>
          {label}
        </label>
      )}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          padding: "9px 12px",
          borderRadius: 8,
          border: `1px solid ${C.gray200}`,
          fontSize: 14,
          color: C.gray800,
          background: C.white,
          outline: "none",
        }}
      />
    </div>
  );
}

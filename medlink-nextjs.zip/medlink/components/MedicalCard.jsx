"use client";
import { C } from "../lib/constants";
import { Avatar, Badge } from "./UI";

export default function MedicalCard({ patient }) {
  const bmi = (patient.weight / (patient.height / 100) ** 2).toFixed(1);

  return (
    <div
      style={{
        width: "100%",
        maxWidth: 380,
        borderRadius: 24,
        overflow: "hidden",
        boxShadow: "0 8px 32px rgba(10,95,168,0.18)",
      }}
    >
      {/* Header gradient */}
      <div
        style={{
          background: `linear-gradient(135deg, ${C.navy} 0%, ${C.blueM} 100%)`,
          padding: "24px 24px 20px",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
          }}
        >
          <div>
            <div
              style={{
                color: "rgba(255,255,255,0.55)",
                fontSize: 10,
                fontWeight: 700,
                letterSpacing: "0.1em",
                marginBottom: 6,
              }}
            >
              MEDLINK HEALTH ID
            </div>
            <div style={{ color: C.white, fontSize: 22, fontWeight: 700 }}>
              {patient.name}
            </div>
            <div
              style={{
                color: "rgba(255,255,255,0.55)",
                fontSize: 12,
                marginTop: 2,
              }}
            >
              {patient.medicalId}
            </div>
          </div>
          <Avatar
            initials={patient.name
              .split(" ")
              .map((n) => n[0])
              .join("")}
            size={52}
            bg="rgba(255,255,255,0.15)"
            color="#fff"
          />
        </div>

        <div style={{ display: "flex", gap: 20, marginTop: 20 }}>
          {[
            ["BLOOD", patient.blood],
            [
              "AGE",
              new Date().getFullYear() - new Date(patient.dob).getFullYear(),
            ],
            ["BMI", bmi],
            ["SEX", patient.gender[0]],
          ].map(([l, v]) => (
            <div key={l}>
              <div
                style={{
                  color: "rgba(255,255,255,0.45)",
                  fontSize: 9,
                  fontWeight: 700,
                  letterSpacing: "0.08em",
                }}
              >
                {l}
              </div>
              <div
                style={{
                  color: C.white,
                  fontSize: 18,
                  fontWeight: 700,
                  marginTop: 2,
                }}
              >
                {v}
              </div>
            </div>
          ))}
          <div>
            <div
              style={{
                color: "rgba(255,255,255,0.45)",
                fontSize: 9,
                fontWeight: 700,
                letterSpacing: "0.08em",
              }}
            >
              DONOR
            </div>
            <div
              style={{
                color: C.emeraldM,
                fontSize: 12,
                fontWeight: 700,
                marginTop: 4,
              }}
            >
              ✓ {patient.donorStatus.split(" ")[0]}
            </div>
          </div>
        </div>
      </div>

      {/* Allergies */}
      <div
        style={{
          background: C.white,
          padding: "16px 24px",
          borderBottom: `1px solid ${C.gray100}`,
        }}
      >
        <div
          style={{
            fontSize: 10,
            fontWeight: 700,
            color: C.gray400,
            letterSpacing: "0.08em",
            marginBottom: 8,
          }}
        >
          ALLERGIES
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          {patient.allergies.map((a) => (
            <Badge key={a} color={C.red} bg={C.redLight}>
              {a}
            </Badge>
          ))}
        </div>
      </div>

      {/* Emergency contact */}
      <div
        style={{
          background: C.white,
          padding: "16px 24px",
          borderBottom: `1px solid ${C.gray100}`,
        }}
      >
        <div
          style={{
            fontSize: 10,
            fontWeight: 700,
            color: C.gray400,
            letterSpacing: "0.08em",
            marginBottom: 8,
          }}
        >
          EMERGENCY CONTACT
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: C.gray800 }}>
              {patient.emergencyContact.name}
            </div>
            <div style={{ fontSize: 12, color: C.gray400 }}>
              {patient.emergencyContact.relation} ·{" "}
              {patient.emergencyContact.phone}
            </div>
          </div>
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: "50%",
              background: C.emeraldLight,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 18,
            }}
          >
            📞
          </div>
        </div>
      </div>

      {/* Insurance + QR */}
      <div
        style={{
          background: C.white,
          padding: "16px 24px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div>
          <div
            style={{
              fontSize: 10,
              fontWeight: 700,
              color: C.gray400,
              letterSpacing: "0.08em",
              marginBottom: 4,
            }}
          >
            INSURANCE
          </div>
          <div style={{ fontSize: 13, fontWeight: 600, color: C.gray800 }}>
            {patient.insurance}
          </div>
          <div style={{ fontSize: 11, color: C.gray400 }}>
            Policy #{patient.policyNo}
          </div>
        </div>
        <div
          style={{
            width: 72,
            height: 72,
            background: C.gray50,
            borderRadius: 12,
            border: `1px solid ${C.gray200}`,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 2,
          }}
        >
          <div style={{ fontSize: 28 }}>⊞</div>
          <div style={{ fontSize: 9, color: C.gray400, fontWeight: 600 }}>
            SCAN QR
          </div>
        </div>
      </div>

      {/* Footer */}
      <div
        style={{
          background: C.navy,
          padding: "10px 24px",
          display: "flex",
          justifyContent: "space-between",
        }}
      >
        <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 10 }}>
          medlink.health
        </span>
        <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 10 }}>
          Valid 2025–2026
        </span>
      </div>
    </div>
  );
}

"use client";
import { useState } from "react";
import { C } from "../lib/constants";
import { Input } from "./UI";

export default function AuthScreen({ onLogin }) {
  const [mode, setMode] = useState("login");
  const [role, setRole] = useState("patient");
  const [email, setEmail] = useState("arjun@email.com");
  const [pass, setPass] = useState("demo123");
  const [name, setName] = useState("");

  return (
    <div
      style={{
        minHeight: "100vh",
        background: C.bg,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          background: C.white,
          borderRadius: 24,
          overflow: "hidden",
          width: 440,
          boxShadow: "0 20px 60px rgba(0,0,0,0.12)",
        }}
      >
        {/* Header */}
        <div
          style={{
            background: `linear-gradient(135deg, ${C.navy} 0%, ${C.blueM} 100%)`,
            padding: "40px 40px 30px",
            textAlign: "center",
          }}
        >
          <div style={{ fontSize: 36, marginBottom: 10 }}>🏥</div>
          <div
            style={{
              fontSize: 28,
              fontWeight: 800,
              color: C.white,
              letterSpacing: "-0.5px",
            }}
          >
            MedLink
          </div>
          <div
            style={{
              fontSize: 14,
              color: "rgba(255,255,255,0.6)",
              marginTop: 4,
            }}
          >
            Your universal medical identity
          </div>
        </div>

        <div style={{ padding: "30px 40px 40px" }}>
          {/* Tabs */}
          <div
            style={{
              display: "flex",
              background: C.gray100,
              borderRadius: 10,
              padding: 4,
              marginBottom: 24,
            }}
          >
            {["login", "register"].map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                style={{
                  flex: 1,
                  padding: "8px",
                  borderRadius: 8,
                  border: "none",
                  cursor: "pointer",
                  fontSize: 14,
                  fontWeight: 600,
                  background: mode === m ? C.white : "transparent",
                  color: mode === m ? C.blue : C.gray400,
                  boxShadow:
                    mode === m ? "0 1px 3px rgba(0,0,0,0.1)" : "none",
                  transition: "all 0.2s",
                }}
              >
                {m === "login" ? "Sign In" : "Register"}
              </button>
            ))}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {mode === "register" && (
              <Input
                label="Full Name"
                value={name}
                onChange={setName}
                placeholder="Your full name"
              />
            )}
            <Input
              label="Email"
              value={email}
              onChange={setEmail}
              type="email"
              placeholder="email@example.com"
            />
            <Input
              label="Password"
              value={pass}
              onChange={setPass}
              type="password"
              placeholder="••••••••"
            />

            {mode === "register" && (
              <div>
                <div
                  style={{
                    fontSize: 12,
                    fontWeight: 600,
                    color: C.gray600,
                    marginBottom: 8,
                  }}
                >
                  I am a
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {["patient", "doctor", "hospital", "caregiver", "school"].map(
                    (r) => (
                      <button
                        key={r}
                        onClick={() => setRole(r)}
                        style={{
                          padding: "6px 16px",
                          borderRadius: 20,
                          border: `1.5px solid ${
                            role === r ? C.blue : C.gray200
                          }`,
                          background:
                            role === r ? C.blueLight : "transparent",
                          color: role === r ? C.blue : C.gray600,
                          fontSize: 13,
                          fontWeight: 600,
                          cursor: "pointer",
                          textTransform: "capitalize",
                        }}
                      >
                        {r}
                      </button>
                    )
                  )}
                </div>
              </div>
            )}

            <button
              onClick={onLogin}
              style={{
                width: "100%",
                padding: "14px",
                borderRadius: 12,
                border: "none",
                background: `linear-gradient(135deg, ${C.navy} 0%, ${C.blueM} 100%)`,
                color: C.white,
                fontSize: 16,
                fontWeight: 700,
                cursor: "pointer",
                marginTop: 4,
              }}
            >
              {mode === "login" ? "Sign In →" : "Create Account →"}
            </button>

            {mode === "login" && (
              <div
                style={{ textAlign: "center", fontSize: 12, color: C.gray400 }}
              >
                Demo: email pre-filled · Click Sign In to continue
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

"use client";
import { C } from "../lib/constants";
import { Card, StatCard, SectionTitle, Badge } from "./UI";
import MedicalCard from "./MedicalCard";

export default function PatientDashboard({
  patient,
  medications,
  records,
  appointments,
  vaccinations,
  setMedications,
}) {
  const today = medications.filter((m) => m.active);
  const taken = today.filter((m) => m.taken).length;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Stats row */}
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <StatCard
          label="Medications Today"
          value={`${taken}/${today.length}`}
          color={C.blue}
        />
        <StatCard
          label="Active Conditions"
          value={patient.conditions.length}
          color={C.amber}
        />
        <StatCard
          label="Records Stored"
          value={records.length}
          color={C.emerald}
        />
        <StatCard
          label="Upcoming Appts"
          value={appointments.length}
          color={C.blueM}
        />
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1.2fr",
          gap: 20,
        }}
      >
        {/* Medical Card */}
        <div>
          <SectionTitle>Your Medical Card</SectionTitle>
          <MedicalCard patient={patient} />
        </div>

        {/* Right column */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Medications */}
          <Card>
            <SectionTitle>Medications Today</SectionTitle>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {medications
                .filter((m) => m.active)
                .map((med) => (
                  <div
                    key={med.id}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 12,
                      padding: "10px 14px",
                      background: med.taken ? C.emeraldLight : C.gray50,
                      borderRadius: 12,
                      border: `1px solid ${med.taken ? "#B6E8D6" : C.gray200}`,
                    }}
                  >
                    <div
                      onClick={() =>
                        setMedications((ms) =>
                          ms.map((m) =>
                            m.id === med.id ? { ...m, taken: !m.taken } : m
                          )
                        )
                      }
                      style={{
                        width: 24,
                        height: 24,
                        borderRadius: "50%",
                        border: `2px solid ${med.taken ? C.emerald : C.gray400}`,
                        background: med.taken ? C.emerald : "transparent",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                      }}
                    >
                      {med.taken && (
                        <span
                          style={{
                            color: C.white,
                            fontSize: 14,
                            fontWeight: 700,
                          }}
                        >
                          ✓
                        </span>
                      )}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div
                        style={{
                          fontWeight: 700,
                          fontSize: 14,
                          color: C.gray800,
                        }}
                      >
                        {med.name}
                      </div>
                      <div style={{ fontSize: 12, color: C.gray400 }}>
                        {med.dose} · {med.time}
                      </div>
                    </div>
                    <Badge
                      color={med.taken ? C.emerald : C.gray600}
                      bg={med.taken ? C.emeraldLight : C.gray100}
                    >
                      {med.taken ? "Taken" : "Pending"}
                    </Badge>
                  </div>
                ))}
            </div>
          </Card>

          {/* Appointments */}
          <Card>
            <SectionTitle>Upcoming Appointments</SectionTitle>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {appointments.map((apt) => (
                <div
                  key={apt.id}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 12,
                    padding: "10px 14px",
                    background: C.blueLight,
                    borderRadius: 12,
                    border: `1px solid #C4DEFA`,
                  }}
                >
                  <div style={{ fontSize: 24 }}>
                    {apt.type === "Video" ? "🎥" : "🏥"}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div
                      style={{
                        fontWeight: 700,
                        fontSize: 14,
                        color: C.gray800,
                      }}
                    >
                      {apt.doctor}
                    </div>
                    <div style={{ fontSize: 12, color: C.gray400 }}>
                      {apt.spec} · {apt.date} · {apt.time}
                    </div>
                  </div>
                  <Badge color={C.blue} bg={C.blueLight}>
                    {apt.type}
                  </Badge>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Records + Vaccinations */}
      <div
        style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}
      >
        <Card>
          <SectionTitle>Medical Records</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {records.map((r) => (
              <div
                key={r.id}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "10px 12px",
                  borderRadius: 10,
                  background: C.gray50,
                  border: `1px solid ${C.gray200}`,
                }}
              >
                <div style={{ fontSize: 22 }}>
                  {r.category === "Lab"
                    ? "🧪"
                    : r.category === "Radiology"
                    ? "🔬"
                    : "💊"}
                </div>
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      fontWeight: 600,
                      fontSize: 13,
                      color: C.gray800,
                    }}
                  >
                    {r.name}
                  </div>
                  <div style={{ fontSize: 11, color: C.gray400 }}>
                    {r.type} · {r.date}
                  </div>
                </div>
                <Badge
                  color={
                    r.status === "Active"
                      ? C.emerald
                      : r.status === "Normal"
                      ? C.blue
                      : C.gray600
                  }
                  bg={
                    r.status === "Active"
                      ? C.emeraldLight
                      : r.status === "Normal"
                      ? C.blueLight
                      : C.gray100
                  }
                >
                  {r.status}
                </Badge>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionTitle>Vaccinations</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {vaccinations.map((v) => (
              <div
                key={v.id}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "10px 12px",
                  borderRadius: 10,
                  background: C.gray50,
                  border: `1px solid ${C.gray200}`,
                }}
              >
                <div style={{ fontSize: 22 }}>💉</div>
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      fontWeight: 600,
                      fontSize: 13,
                      color: C.gray800,
                    }}
                  >
                    {v.name}
                  </div>
                  <div style={{ fontSize: 11, color: C.gray400 }}>
                    Given: {v.date}
                    {v.due ? ` · Due: ${v.due}` : ""}
                  </div>
                </div>
                <Badge
                  color={
                    v.status === "Complete"
                      ? C.emerald
                      : v.status === "Due Soon"
                      ? C.amber
                      : C.blue
                  }
                  bg={
                    v.status === "Complete"
                      ? C.emeraldLight
                      : v.status === "Due Soon"
                      ? C.amberLight
                      : C.blueLight
                  }
                >
                  {v.status}
                </Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

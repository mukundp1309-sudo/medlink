"use client";
import { useState, useEffect, useRef } from "react";
import { C } from "../lib/constants";
import { Card, SectionTitle, Btn } from "./UI";

export default function AIAssistant({ patient }) {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: `Hello ${patient.name.split(" ")[0]}! I'm your MedLink AI Health Assistant. I can explain your reports, check medication interactions, answer health questions, and more. How can I help you today?`,
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  const systemPrompt = `You are MedLink AI, a helpful and empathetic health assistant embedded in the MedLink platform.
Patient profile: ${patient.name}, ${new Date().getFullYear() - new Date(patient.dob).getFullYear()} year old ${patient.gender}, Blood group ${patient.blood}.
Allergies: ${patient.allergies.join(", ")}.
Conditions: ${patient.conditions.join(", ")}.
Current medications: Amlodipine 5mg (daily), Vitamin D3 1000IU (daily), Cetirizine 10mg (as needed).
Lifestyle: Smoking: ${patient.smoking}, Alcohol: ${patient.alcohol}, Exercise: ${patient.exercise}.

Be helpful, empathetic, and clear. Always include a disclaimer that you're an AI and serious concerns should be discussed with a real doctor. Keep responses concise and formatted nicely. Do not recommend specific diagnoses.`;

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role: "user", content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/claude", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          system: systemPrompt,
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          max_tokens: 1000,
        }),
      });
      const data = await res.json();
      const reply =
        data.content?.[0]?.text || "Sorry, I couldn't process that right now.";
      setMessages((ms) => [...ms, { role: "assistant", content: reply }]);
    } catch {
      setMessages((ms) => [
        ...ms,
        {
          role: "assistant",
          content:
            "Sorry, I'm having trouble connecting right now. Please try again.",
        },
      ]);
    }
    setLoading(false);
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const quickQ = [
    "Explain my CBC report results",
    "Is Amlodipine safe long-term?",
    "What are Penicillin allergy risks?",
    "How to manage hypertension naturally?",
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "70vh" }}>
      <SectionTitle>AI Health Assistant</SectionTitle>
      <Card
        style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}
        p={0}
      >
        {/* Messages */}
        <div
          style={{
            flex: 1,
            overflowY: "auto",
            padding: 20,
            display: "flex",
            flexDirection: "column",
            gap: 14,
          }}
        >
          {messages.map((m, i) => (
            <div
              key={i}
              style={{
                display: "flex",
                gap: 10,
                flexDirection: m.role === "user" ? "row-reverse" : "row",
              }}
            >
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: "50%",
                  background: m.role === "user" ? C.blue : C.emerald,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 16,
                  flexShrink: 0,
                }}
              >
                {m.role === "user" ? "👤" : "🤖"}
              </div>
              <div
                style={{
                  maxWidth: "75%",
                  padding: "12px 16px",
                  borderRadius:
                    m.role === "user"
                      ? "18px 18px 4px 18px"
                      : "18px 18px 18px 4px",
                  background: m.role === "user" ? C.blue : C.gray50,
                  color: m.role === "user" ? C.white : C.gray800,
                  fontSize: 14,
                  lineHeight: 1.6,
                  border:
                    m.role === "user" ? "none" : `1px solid ${C.gray200}`,
                  whiteSpace: "pre-wrap",
                }}
              >
                {m.content}
              </div>
            </div>
          ))}

          {loading && (
            <div style={{ display: "flex", gap: 10 }}>
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: "50%",
                  background: C.emerald,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 16,
                }}
              >
                🤖
              </div>
              <div
                style={{
                  padding: "12px 16px",
                  borderRadius: "18px 18px 18px 4px",
                  background: C.gray50,
                  border: `1px solid ${C.gray200}`,
                  display: "flex",
                  gap: 4,
                  alignItems: "center",
                }}
              >
                {[0, 0.2, 0.4].map((d, i) => (
                  <div
                    key={i}
                    style={{
                      width: 7,
                      height: 7,
                      borderRadius: "50%",
                      background: C.gray400,
                      animation: "pulse 1.2s ease-in-out infinite",
                      animationDelay: `${d}s`,
                    }}
                  />
                ))}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Quick questions */}
        {messages.length === 1 && (
          <div
            style={{
              padding: "0 20px 12px",
              display: "flex",
              flexWrap: "wrap",
              gap: 8,
            }}
          >
            {quickQ.map((q) => (
              <button
                key={q}
                onClick={() => setInput(q)}
                style={{
                  padding: "7px 14px",
                  borderRadius: 20,
                  fontSize: 12,
                  fontWeight: 600,
                  cursor: "pointer",
                  border: `1.5px solid ${C.blue}`,
                  background: C.blueLight,
                  color: C.blue,
                }}
              >
                {q}
              </button>
            ))}
          </div>
        )}

        {/* Input bar */}
        <div
          style={{
            padding: "12px 16px",
            borderTop: `1px solid ${C.gray200}`,
            display: "flex",
            gap: 10,
          }}
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Ask about your health, medications, reports..."
            style={{
              flex: 1,
              padding: "10px 16px",
              borderRadius: 25,
              border: `1.5px solid ${C.gray200}`,
              fontSize: 14,
              outline: "none",
              background: C.gray50,
            }}
          />
          <Btn onClick={send} style={{ borderRadius: 25, padding: "10px 20px" }}>
            {loading ? "..." : "Send →"}
          </Btn>
        </div>
      </Card>
    </div>
  );
}

export const metadata = {
  title: "MedLink — Universal Health ID",
  description:
    "MedLink is your universal medical identity platform — manage health records, medications, appointments, and emergency info in one place.",
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body style={{ margin: 0, padding: 0, boxSizing: "border-box" }}>
        {children}
      </body>
    </html>
  );
}

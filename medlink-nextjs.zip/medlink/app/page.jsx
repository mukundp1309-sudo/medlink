"use client";
import "./globals.css";
import { useState, useEffect } from "react";
import { C, INIT_PATIENT, INIT_MEDICATIONS, INIT_RECORDS, INIT_APPOINTMENTS, INIT_VACCINATIONS } from "../lib/constants";
import { getStorage, setStorage } from "../lib/storage";
import { Avatar } from "../components/UI";
import AuthScreen from "../components/AuthScreen";
import PatientDashboard from "../components/PatientDashboard";
import HealthProfile from "../components/HealthProfile";
import AIAssistant from "../components/AIAssistant";
import EmergencyMode from "../components/EmergencyMode";
import DoctorDashboard from "../components/DoctorDashboard";
import HospitalDashboard from "../components/HospitalDashboard";
import AdminDashboard from "../components/AdminDashboard";

const NAV = [
  { id: "dashboard", label: "Dashboard", icon: "🏠" },
  { id: "profile", label: "My Profile", icon: "👤" },
  { id: "ai", label: "AI Assistant", icon: "🤖" },
  { id: "emergency", label: "Emergency", icon: "🆘" },
  { id: "doctor", label: "Doctor View", icon: "🩺" },
  { id: "hospital", label: "Hospital", icon: "🏥" },
  { id: "admin", label: "Admin", icon: "⚙️" },
];

export default function MedLinkApp() {
  const [authed, setAuthed] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [patient, setPatient] = useState(INIT_PATIENT);
  const [medications, setMedications] = useState(INIT_MEDICATIONS);
  const records = INIT_RECORDS;
  const appointments = INIT_APPOINTMENTS;
  const vaccinations = INIT_VACCINATIONS;

  // Load persisted data on mount
  useEffect(() => {
    const savedPatient = getStorage("medlink:patient");
    if (savedPatient) setPatient(savedPatient);
    const savedMeds = getStorage("medlink:medications");
    if (savedMeds) setMedications(savedMeds);
  }, []);

  // Persist on change
  useEffect(() => {
    if (authed) setStorage("medlink:patient", patient);
  }, [patient, authed]);

  useEffect(() => {
    if (authed) setStorage("medlink:medications", medications);
  }, [medications, authed]);

  if (!authed) return <AuthScreen onLogin={() => setAuthed(true)} />;

  return (
    <div
      style={{
        display: "flex",
        minHeight: "100vh",
        background: C.bg,
        fontFamily: "'Segoe UI', system-ui, sans-serif",
      }}
    >
      {/* ── Sidebar ─────────────────────────────────────────────────── */}
      <div
        style={{
          width: 220,
          background: C.navy,
          display: "flex",
          flexDirection: "column",
          flexShrink: 0,
          position: "sticky",
          top: 0,
          height: "100vh",
        }}
      >
        {/* Logo */}
        <div
          style={{
            padding: "24px 20px 20px",
            borderBottom: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          <div
            style={{
              fontSize: 22,
              fontWeight: 800,
              color: C.white,
              letterSpacing: "-0.5px",
            }}
          >
            🏥 MedLink
          </div>
          <div
            style={{
              fontSize: 11,
              color: "rgba(255,255,255,0.4)",
              marginTop: 2,
            }}
          >
            Universal Health ID
          </div>
        </div>

        {/* Nav */}
        <nav
          style={{
            flex: 1,
            padding: "12px 10px",
            display: "flex",
            flexDirection: "column",
            gap: 2,
          }}
        >
          {NAV.map((n) => (
            <button
              key={n.id}
              onClick={() => setActiveTab(n.id)}
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                gap: 10,
                padding: "11px 14px",
                borderRadius: 10,
                border: "none",
                cursor: "pointer",
                background:
                  activeTab === n.id
                    ? "rgba(255,255,255,0.12)"
                    : "transparent",
                color:
                  activeTab === n.id ? C.white : "rgba(255,255,255,0.5)",
                fontSize: 14,
                fontWeight: activeTab === n.id ? 700 : 500,
                textAlign: "left",
                transition: "all 0.15s",
              }}
            >
              <span>{n.icon}</span> {n.label}
              {n.id === "emergency" && (
                <span
                  style={{
                    marginLeft: "auto",
                    width: 8,
                    height: 8,
                    borderRadius: "50%",
                    background: C.red,
                  }}
                />
              )}
            </button>
          ))}
        </nav>

        {/* User pill */}
        <div
          style={{
            padding: "14px 14px 20px",
            borderTop: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Avatar
              initials={patient.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
              size={34}
              bg="rgba(255,255,255,0.15)"
              color="#fff"
            />
            <div>
              <div style={{ color: C.white, fontSize: 13, fontWeight: 600 }}>
                {patient.name.split(" ")[0]}
              </div>
              <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 11 }}>
                {patient.medicalId}
              </div>
            </div>
          </div>
          <button
            onClick={() => setAuthed(false)}
            style={{
              marginTop: 12,
              width: "100%",
              padding: "7px",
              borderRadius: 8,
              border: "1px solid rgba(255,255,255,0.15)",
              background: "transparent",
              color: "rgba(255,255,255,0.5)",
              fontSize: 12,
              cursor: "pointer",
            }}
          >
            Sign Out
          </button>
        </div>
      </div>

      {/* ── Main content ─────────────────────────────────────────────── */}
      <div style={{ flex: 1, overflow: "auto" }}>
        <div
          style={{ maxWidth: 1100, margin: "0 auto", padding: "30px 30px" }}
        >
          {activeTab === "dashboard" && (
            <PatientDashboard
              patient={patient}
              medications={medications}
              records={records}
              appointments={appointments}
              vaccinations={vaccinations}
              setMedications={setMedications}
            />
          )}
          {activeTab === "profile" && (
            <HealthProfile patient={patient} setPatient={setPatient} />
          )}
          {activeTab === "ai" && <AIAssistant patient={patient} />}
          {activeTab === "emergency" && <EmergencyMode patient={patient} />}
          {activeTab === "doctor" && <DoctorDashboard />}
          {activeTab === "hospital" && <HospitalDashboard />}
          {activeTab === "admin" && <AdminDashboard />}
        </div>
      </div>
    </div>
  );
}
